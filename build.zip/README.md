# abi-clerk-lambda
Lambda function for the ABI Clerk

From the repository root directory, build with command:

```sh
zip -r abi-clerk-lambda.zip *
```
